import sys

def main():
    print(sys.argv)

if __name__ == "__main__":
    main()
